function x = crout( aa, b )
%
% Function: crout
%
% Solves the system of linear equation Ax = b using LU decomposition
% where A is a tridiagonal matrix.
% 
% Taken from Algorithm 6.7 from Burden and Faires.
%
% Inputs: aa - the matrix A
%          b - the right-hand side vector b
%
% Outputs: x - the solution vector
%

a = [aa b];

n = size(aa, 1);

l = zeros(n, n+1);
u = zeros(n, n+1);
z = zeros(n, 1);
x = zeros(n, 1);

l(1, 1) = a(1, 1);
u(1, 2) = a(1, 2) / l(1, 1);
z(1) = a(1, n + 1) / l(1, 1);

for i = 2:(n - 1)
   
   l(i, i - 1) = a(i, i - 1);
   l(i, i)     = a(i, i) - l(i, i - 1) * u(i - 1, i);
   
   u(i, i + 1) = a(i, i + 1) / l(i, i);
   z(i)        = (a(i, n + 1) - l(i, i - 1) * z(i - 1)) / l(i, i);
   
end

l(n, n - 1) = a(n, n - 1);
l(n, n)     = a(n, n) - l(n, n - 1) * u(n - 1, n);
z(n)        = (a(n, n + 1) - l(n, n - 1) * z(n - 1)) / l(n, n);

x(n) = z(n);

for i = (n - 1):-1:1
   
   x(i) = z(i) - u(i, i + 1) * x(i + 1);

end

