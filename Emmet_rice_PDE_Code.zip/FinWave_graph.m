clc
clear all
maxtimes=2000;
 deltax=0.0125;
 deltat=0.005;
 maxxpts = floor(((2.0 * pi) / deltax)+1);


[uxt, xpts, times] = FinDifWaveFn(maxtimes, deltat, deltax, maxxpts);


plot2 = subplot(2, 2, [1 4]);

surf(xpts, times, uxt)
shading interp

xlim([0, 2 * pi]);
%ylim([0 2.0]);
zlim([-2.0 2.0]);

set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
	 'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
	 'FontSize', 14)   
   
mytitle = [{'Time Evolution of ','Wave Equation Finite Difference Approximation'}];
xlabel('X', 'FontSize', 14)
ylabel('Time(t)', 'FontSize', 14)
zlabel('u(x,t)', 'FontSize', 14)
title(mytitle, 'FontSize', 14)

axis square