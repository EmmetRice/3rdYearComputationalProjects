clc
close all;
clear all;

% 
% deltat	3.125000e-04 	deltax	1.250000e-01


global gn %a global value for 'n' iterations
.......l

%using exact deltat and deltax needed for convergence

deltat     = 6.25e-04;
maxtimes1  = 500;%number of steps
maxtimes2  = 3000;
maxtimes=10;
%using 1 to get intial condition within tolerance

deltax=1.25e-02;
maxxpts = floor(((2.0 * pi) / deltax)+1);

maxseries1=250;
maxseries2=250;

[uxt1,xpts,an,bn,times1] = FourierWaveFn(maxtimes1, deltat, deltax,maxseries1);
[uxt2,xpts,an,bn,times2] = FourierWaveFn(maxtimes2, deltat, deltax,maxseries1);

%  [uxt1, xpts,an,times] = FourierHeatFn(maxtimes, deltat, deltax,maxseries1);
%  
%  [uxt2, xpts,an,times2] = FourierHeatFn(maxtimes, deltat, deltax,maxseries2);
%  
%  [Finuxt] = CrankNichFn(maxtimes, deltat, deltax, maxxpts);
%  
 
intuxt1 = (uxt1(end,:));
intuxt2 = (uxt2(end,:));
% intFinuxt = (Finuxt(1,:));

plot3 = subplot(1, 2, 1);
plot(xpts,intuxt1,'-b')
 mytitle = sprintf(' Square Wave Intial Condition\n Fourier Wave Equation Approximation for  %i timesteps',maxtimes1);
 xlabel('x', 'FontSize', 14)
 ylabel('u(x,t)', 'FontSize', 14)
 xlim([0, 2*pi])
 title(mytitle, 'FontSize', 12)
% hold on
% plot(xpts,intFinuxt,'r--','Markersize',8)
% legend('Fourier','Exact')
% hold off



plot5 = subplot(1, 2, 2);
plot(xpts,intuxt2,'-b')
mytitle = sprintf(' Square Wave Intial Condition\n Fourier Wave Equation Approximation for  %i timesteps',maxtimes2);
 xlabel('x', 'FontSize', 14)
 ylabel('u(x,t)', 'FontSize', 14)
 xlim([0, 2*pi])
 title(mytitle, 'FontSize', 12)
% hold on
% plot(xpts,intFinuxt,'r--','Markersize',8)
% legend('Fourier','Exact')
% hold off

reduced_chi2 = Chi(intuxt1,intFinuxt,1)
reduced_chi22 = Chi(intuxt2,intFinuxt,1)

function Chi2 = Chi(odata,edata,nepara)
    Chi2=sum(((odata-edata).^2)/edata)/(length(edata)-nepara-1);
    
end