function myint = series_f_Wave_an( x )

    global gn

    a                = 0 * x;

    a(find(pi - 2 <= x <= pi + 2))  = 1; %sets up intial values ie u(x,0)
    a(find(x > pi + 2)) = 0;
    a(find(x < pi - 2)) = 0;

    % a here is U(x,0)
    
    % a(find(x < pi))  = x(x < pi) / pi;
    % a(find(x >= pi)) = sin(x(x >= pi) / 2);

    myint = a .* sin(gn * x / 2); %terms in "an" integral
     

end
