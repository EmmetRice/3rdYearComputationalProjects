clc
close all;
clear all;
%finite diff wave equation

% maxtimepts = 10000; %num of time steps
% deltat     = 0.0001; %sise time step
% %maxxpts    = 1001; %num of spatial grid points ie N. there will thus be N-1 STeps
% %deltax     = (2.0 * pi) / (maxxpts - 1); %1 less step than num grid pts
% deltax     = 6.283185e-04;
% CFLtest1 = deltax/deltat;


% fprintf('deltax \t%d\n',deltax)
% fprintf('deltat \t%d\n',deltat)
% fprintf('CFLtest1\t%d\n',CFLtest1)

counter      = 0;
counterLimit = 100;


%toldesired = input('Input esired tolerance for convergence, example 1e-03  ');
toldesired = 0.1;
toldesiredtime = 0.1;
tol = 1;
%deltax = input('......');

maxtimepts = 300; %num of time steps
deltat = 0.01;
deltax = (2*pi/5);

flag = 0;
k = 2.0;
%for convergence

tolpre = 100;
tol = 10;


    while tol > toldesired  &&counter < counterLimit  %so does not run forever
    %     
       
         
         if counter == counterLimit
          warning('failed')
         end
         
         maxxpts1 = floor(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
         [uxttest1, xpts1] = CrankNichFn(maxtimepts, deltat, deltax,maxxpts1);  
       
       
        deltax2 = 0.5*deltax; %choosing smaller delta x to get to convergence
%         maxxpts1 = floor(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
        maxxpts2 = (2*maxxpts1)-1;
        fprintf('\nrunning\n')
%         [uxttest1, xpts1] = CrankNichFn(maxtimepts, deltat, deltax,maxxpts1);
        [uxttest2, xpts2] = CrankNichFn(maxtimepts, deltat, deltax2,maxxpts2);

        oddxpts2 = xpts2(1:2:end,:); %selects odd row elemets so xpts match up
        odduxttest2 = uxttest2(:, 1:2:end); %chooses only odd columns
        % ie so that x values match up

        %xpts1 - oddxpts2 shows that everyother xpt lines up

    %     fprintf('size uxtest1 \t%d\n',size(uxttest1));
    %     fprintf('size uxtest2 \t%d\n',size(uxttest2));
    %     fprintf('size odduxtest2 \t%d\n',size(odduxttest2));
        %test 2 has twice as many points as 1, but as matlab array start at 1,
        %all odd elements will line up

        %tol = (norm(uxttest1 - odduxttest2)); %norm function takes largeest value
        %IDEALLY would use norm function, choosing largest discrepancy within
        %tolerance, but due to gibs, this is an unrealistic measure
       %while strictly worse analysis, in order to show convergence, taking the
       %average value of the difference

%        colmean = mean(abs(uxttest1 - odduxttest2));
%        tol = mean(colmean);

        tol = (norm(uxttest1 - odduxttest2));
       
        fprintf ('\nTemporary results...\n')
      
        fprintf('deltat\t%d \tdeltax\t%d\n',deltat, deltax)
        fprintf('tol\t%.3f\n',tol)
                
       


        
       
        counter = counter + 1; 

        if tol > tolpre
        deltax = 2* deltax; %as now within tolerance, choose larger  deltax)
        %fprintf('\nCOMPLETE\n')
        fprintf(2,'\nBREAKING DUE TO ARTEFACTS\n')
        %             fprintf('deltax = %d required for convergence at deltat = %d\n',deltax, deltat)
        fprintf('Tolpre\t%d deltaxpre \t%d\n',tolpre,deltax)
                
         break  %Break out and cant go any smaller. Can cealrly see odd things
%          occuring in the video 
        
%         attempting to get past the oddness to continue converging

%          deltax2 = 4*deltax;
%          deltat=0.5*deltat;
        end
        
        
         tolpre = tol;
         deltax = deltax2; %for next loop iteration
         uxttest1 = uxttest2;
         maxxpts1 = maxxpts2;

      
          
        
         
        if tol <= toldesired 

            deltax = 2* deltax; %as now within tolerance, choose larger  deltax)
            fprintf('\nCOMPLETE\n')
            fprintf('deltax = %d required for convergence at deltat = %d\n',deltax, deltat)
            fprintf('Tolerance desired\t%d\n',toldesired)
            fprintf('average difference in uxt\t%d\n',tol)
            
        end
   
       
    
    
    end    
       
   
  

    % FOR SHOWING MASSIVE differences at step points
    % %     diff = (uxttest1 - odduxttest2);
    %     %plot(xpts1, diff(20,:), '-r')
    %     plot(xpts1, uxttest1(20,:), '-r')
    %     hold on
    %     plot (xpts1, odduxttest2(20,:), '-b')

    

    
    
    %CONVERGENCE of DELTA T
    
    %DELTA X CARRIED FORWARD FROM CONVERGENCE ABOVE
    
tol2 = 1;    

disp('STARTING TEMPORAL')
maxxpts = floor(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
[uxttest1] = CrankNichFn(maxtimepts, deltat, deltax, maxxpts);

toldesired = toldesiredtime;

while tol2 > toldesired && counter < counterLimit %so does not run forever
    %     
              
    
    if counter == counterLimit
          warning('failed')
    end
    
    deltat2 = 0.5*deltat; %choosing smaller delta t to get to convergence
    
   
    maxtimepts2 = 2*maxtimepts; %smaller deltat = twice pts
    
    fprintf('\nrunning\n')
    
    [uxttest2] = CrankNichFn(maxtimepts2, deltat2, deltax,maxxpts);
    
    
     oddtimeuxttest2 = uxttest2(1:2:end,:); %chooses only odd rows
     % ie so that time values match up (as twice amount)
        
%      rowmean = mean(abs(uxttest1 - oddtimeuxttest2));
%      tol2 = mean(rowmean);
     
     tol2 = (norm(uxttest1 - oddtimeuxttest2));
     
     fprintf ('\nTemporary results...\n')

     fprintf('deltat\t%d \tdeltax\t%d\n',deltat, deltax)
     fprintf('tol\t%.3f\n',tol2)
     
%      disp(deltat*maxtimepts)
%      disp(deltat2*maxtimepts2)
    
     deltat = deltat2; %for next loop iteration
     maxtimepts = maxtimepts2;
     uxttest1 = uxttest2;
     counter = counter + 1;
     
     
     
     if tol2 <= toldesired
         
         deltat = 2* deltat; %as now within tolerance, choose larger  deltax)
         fprintf('\nCOMPLETE TIME CONVERGENCE\n')
         fprintf('deltat = %d required for time convergence at convergent deltax = %d\n',deltat, deltax)
         fprintf('Tolerance desired\t%d\n',toldesired)
         fprintf('average difference in uxt for time convergence\t%d\n',tol2)
     end
end
     
    

fprintf(2,'deltatexact = %d \t deltaxexact = %d\n',deltat, deltax);



fprintf('Running for spatial error analysis');




deltaxexact = deltax;
deltatexact = deltat;

maxxpts1 = ceil(((2.0 * pi) / deltaxexact)+1);

%taken out of loop as exact solution wont change, done for speed



maxz = 50;


%increase accuracy of difference, look for better than double


timeanalysis = 0.5*maxtimepts;

% maxtimepts = 10000;



 Dudx = zeros(maxz,1);
 Dudxav = zeros(maxz,1);
 deltaxsq = zeros(maxz,1);
 deltaxsqrt = zeros(maxz,1);
 deltaxarray = zeros(maxz,1);

% Dudx = ones(maxz,:);
% deltaxsq = ones(maxz,:);

maxxpts1 = floor(((2.0 * pi) / deltaxexact)+1);

%taken out of loop as exact solution wont change, done for speed

deltax = deltaxexact;
deltat = deltatexact;

[uxttest1, xpts1] = CrankNichFn(maxtimepts, deltat, deltax, maxxpts1);



[~,idx1] = min(abs(xpts1-pi));   %finds closest point to pi from exact

zuxttest1 = uxttest1(timeanalysis, idx1);
%array for exact solution value at specific time and closest to pi 

zuxttest1av = uxttest1(timeanalysis, :); 
%average value solution at specific time across all x



for z = 1:maxz  %only uses even integers
    
    w = (1 + (z - 1)/10);
%    if z == 0
%         z = 1;
%        
%    end
   
%    if z == 1
%         z = 3; %so function skips and doesnt repeat = 
%    end
    
%    if  mod(maxxpts1,z)==0
    
    deltax = deltaxexact;
    deltax2 = deltaxexact * w; %increasing deltax for less accurate solution
    deltat = deltatexact;
    
   %READ THIS
    
    %only use xpts value almost equal pi
%     [~,idx] = min(abs(xpts1-pi));   %finds closest point to pi
    %idx = position closest to pi
    %choose this column in uxt (all the time points for pi)
    % for Du 
    
    
    
%         maxxpts1 = ceil(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
        maxxpts2 = floor(maxxpts1/w); %as new deltax is doubling, then will be less xpts
        %floor so that integer number of x points, may not line up exactly
        fprintf('\nrunning\n')
        
        %generating less accurate solution (larger deltax)
        [uxttest2, xpts2] = CrankNichFn(maxtimepts, deltat, deltax2, maxxpts2);

        
        
         
         [~,idx2] = min(abs(xpts2-pi));   %finds closest point to pi from erronious
        
         %as opposed to mod method, there will be error introduced here as
         %its an approximation to closest pi value
         
          
         zuxttest2 = uxttest2(timeanalysis, idx2);
         %chooses coulmn which indexes to pi x values 
        %chosen arbituary time step 100 to compare
        
        Dudx(z) = (abs(zuxttest2 - zuxttest1));
        
        %can see from graph due, very wide spread of differences
        %again this is due to extreme gibs phenomenom
        
        %in order to see trend, again going to tale the average value in an
        %attempt o mitigate this effect, but again this approach is not at
        %all ideal or rigorous
        
        
         zuxttest2av = uxttest2(timeanalysis, :);
        
         %READ
         %Ideally would take the difference between each corresponding xpt
         %then take the average, but requires the number of xpts of the
         %second to be modulus zero of original xpts, not large enough data
         %set
         
         %could also choose multiple close points to arbitaury values and
         %take their difference
         
         
         %instead, and not at all ideally, going to take average value for
         %u at all x points and then take the difference, which as noted is
         %not the same as the other way round, not as good
         
         
         
         
         
         Dudxav(z) = abs(mean(zuxttest2av) - mean(zuxttest1av)); %worse deltax - exactdeltax solution (closest to pi)
         
%         disp (Dudx(z))
        
        deltaxarray(z) = deltax2;
        deltaxsq(z) = deltax2^2;
        deltaxsqrt(z) = deltax2^0.5;
         
         %plot Dudx vs deltax^2 and do chi squared fit
        
        
        %as opposed to convergence, now xpts1 will have more points
        %need to choose points which match up to trial
%         zxpts1 = xpts1(1:z:end,:); %selects rows so elemets so xpts match up
%         zuxttest1 = uxttest1(:, 1:z:end); %skips z many colums each time (x points stored in columns)

%         disp(size(xpts1))
%         disp(size(zxpts1))
        
%          colmean = mean(abs(uxttest2 - zuxttest1)); %worse deltax - exactdeltax solution (matching points)
%          Dudx(z) = mean(colmean); %stores average errorbetween 
%          deltaxsq(z) = ((deltax2)^2);   
%          %plot Dudx vs deltax^2 and do chi squared fit
         
         
%    else
%        continue
%          
%    end     
  
   
graphvalues2 = uxttest2(timeanalysis,:);

%COMMENT MOVIE IN AND OUT AS NEEDED

figure(8)
plot(xpts2,graphvalues2)
mytitle = sprintf("Movie of model as deltax increases away from approxiamte exact dx value\n at time step = %i \t deltax = %0.3e ",timeanalysis,deltax2);
title(mytitle, 'FontSize', 14) 
ylim ([0, 0.15])
xlim ([0, 7])




   
end


%plot1 = subplot(2,2,1);
figure(1)
scatter(deltaxsq,Dudx)
hold on;
coeffs = polyfit(deltaxsq, Dudx, 1);
% Get fitted values
%fittedX = linspace(min(deltaxsq), max(deltaxsq), maxz);
fittedX = (linspace(min(deltaxarray), max(deltaxarray), maxz)).^2;
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
 xlabel("dx Squared");
 ylabel("U Error");
 
mytitle = sprintf("Error Relationship for deltax values against \nsufficently exact dx and dt values at\n closest point to pi at %i timestep",timeanalysis);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')
 
Chi2 = Chi(Dudx,fittedY,5);
disp("fig1")
fprintf(' U error Dx^2 Chi2 = %0.3e\n',Chi2(1));
 
 
 

figure(2)
scatter(deltaxarray,Dudx)
hold on;
coeffs = polyfit(deltaxarray, Dudx, 1);
% Get fitted values
fittedX = linspace(min(deltaxarray), max(deltaxarray), maxz);
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);
hold off;
 xlabel("dx");
 ylabel("U Error");
mytitle = sprintf("Error Relationship for deltax values against \nsufficently exact dx and dt values at\n closest point to pi at %i timestep",timeanalysis);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')

Chi2 = Chi(Dudx,fittedY,5); 
fprintf(' U error Dx Chi2 = %0.3e\n',Chi2(1));



 
 figure(3)
scatter(deltaxsq,Dudxav)
hold on;
coeffs = polyfit(deltaxsq, Dudxav, 1);
% Get fitted values
%fittedX = linspace(min(deltaxsq), max(deltaxsq), maxz);
fittedX = (linspace(min(deltaxarray), max(deltaxarray), maxz)).^2;
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
 xlabel("dx Squared");
 ylabel("Average U Error");
 
 mytitle = sprintf("Error Relationship for deltax values against \nsufficently exact dx and dt values for \n Difference Between the Total Avergae U(x) Value at %i timestep",timeanalysis);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')

 
Chi2 = Chi(Dudxav,fittedY,5);
fprintf(' Average U error Dx^2 Chi2 = %0.3e\n',Chi2(1));
 
 
 
figure(4)
scatter(deltaxarray,Dudxav)
hold on;
coeffs = polyfit(deltaxarray, Dudxav, 1);
% Get fitted values
fittedX = linspace(min(deltaxarray), max(deltaxarray), maxz);
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
 xlabel("dx");
 ylabel("Average U Error");
  mytitle = sprintf("Error Relationship for deltax values against \nsufficently exact dx and dt values for \n Difference Between the Total Avergae U(x) Value at %i timestep",timeanalysis);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')


Chi2 = Chi(Dudxav,fittedY,5);
fprintf(' Average U error Dx Chi2 = %0.3e\n',Chi2(1));
 
 



function Chi2 = Chi(odata,edata,nepara)
    Chi2=sum(((odata-edata).^2)/edata)/(length(edata)-1-nepara);
    
end



 
