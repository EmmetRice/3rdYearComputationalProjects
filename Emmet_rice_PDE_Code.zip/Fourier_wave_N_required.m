clc
close all;
clear all;


%NOTE this code uses anootations from other codes
%It is also inefficent as it recalculates for previous values (see
%maxseries loop) however, it was fas to code. 


global gn %a global value for 'n' iterations
.......l

%using exact deltat and deltax needed for convergence

deltat    = 6.25e-04;
maxtimes  = 1;%number of steps

%using 1 to get intial condition within tolerance

deltax=3.125e-03;
maxxpts = floor(((2.0 * pi) / deltax)+1);

maxseries1=10;

counter      = 0;
counterLimit = 100000;


%toldesired = input('Input esired tolerance for convergence, example 1e-03  ');
toldesired = 5e-03;
tol = 1;



%for convergence


    
    while tol > toldesired && counter < counterLimit %so does not run forever
    

         if counter == counterLimit
          warning('failed')
         end
         
       
        maxseries2 = maxseries1+10;
; %choosing larger maxseries to get to convergence
      
        fprintf('\nrunning\n')
        [uxttest1,xpts] = FourierWaveFn(maxtimes, deltat, deltax,maxseries1);
        [uxttest2,xpts] = FourierWaveFn(maxtimes, deltat, deltax,maxseries2);
      

             colmean = mean(abs(uxttest1 - uxttest2));
       tol = mean(colmean);
       
   

        disp(maxseries1)
        maxseries1 = maxseries2; %for next loop iteration
        counter = counter + 1; 
           
               plot(xpts, uxttest1, '-r')
       
       xlim([0, 2*pi])
     
       
       drawnow
         

        if tol <= toldesired 

            maxseriesmin = maxseries1-10; %as now within tolerance, choose smaller         fprintf('\nCOMPLETE\n')
            fprintf('%i N fourier series required for convergence for intial condition at Tolerance desired\t%d\n',maxseriesmin, toldesired)
            fprintf('Tolerance desired\t%d\n',toldesired)
            fprintf('average difference in uxt\t%d\n',tol)
            
        end
       
    end
    
    plot(xpts,uxttest1)
    mytitle = sprintf('Fourier Wave Equation for N = %f Approximation',maxseries1);
    xlabel('x', 'FontSize', 14)
    ylabel('u(x,t)', 'FontSize', 14)
    xlim([0, 3*pi])
    ylim([-1.2, 1.2])
    title(mytitle, 'FontSize', 14)
    
disp('running to show laternative method of convergence...')
    
%arbituary choices    
 maxtimes=2000;
 deltax=0.0125;
 deltat=0.005;
 maxxpts = floor(((2.0 * pi) / deltax)+1);
 maxseries=maxseries1;
 
    
[uxt,xpts,an,bn,times] = FourierWaveFn(maxtimes, deltat, deltax,maxseries1);

plot2 = subplot(1, 2, [1]);

surf(xpts, times, uxt)
shading interp

xlim([0, 2 * pi]);
%ylim([0 1.0]);
zlim([-2.0 2.0]);

set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
	 'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
	 'FontSize', 14)   
   
mytitle = [{'Time Evolution of ','Wave Equation Fourier Series Approximation'}];
xlabel('X', 'FontSize', 14)
ylabel('Time(t)', 'FontSize', 14)
zlabel('u(x,t)', 'FontSize', 14)
title(mytitle, 'FontSize', 14)

axis square


%convergence plot
plot3 = subplot(1,2,[2]);
x = (1:maxseries);
plot(x, an,'r-','LineWidth', 2)
mytitle = [{'Wave Equation Fourier Series Approximation','Showing Convergence of Coefficents'}];
xlabel('n', 'FontSize', 14)
ylabel('Coefficent Values', 'FontSize', 14)
title(mytitle, 'FontSize', 14)
xlim([0, 100]);
hold on

plot(x,bn,'b*','Markersize', 2)
legend('an coeff','bn coeff')
hold off 

%best just to use absolute difference between two n values converges as n
%gets larger 




disp('complete')
        