function bnfn = series_f_Wave_bn( x)

    global gn

  

    bnfn = gn*(sin(x/2).*sin(gn * x / 2)); %terms in "bn" integral
     





