function myint = series_f_Heat( x )

global gn

a                = 0 * x;

a(find(pi - 1 <= x <= pi + 1))  = 1; %sets up intial values ie u(x,0)
a(find(x > pi + 1)) = 0;
a(find(x < pi - 1)) = 0;

% a(find(x < pi))  = x(x < pi) / pi;
% a(find(x >= pi)) = sin(x(x >= pi) / 2);

myint            = a .* sin(gn * x / 2); %terms in "an" integral
