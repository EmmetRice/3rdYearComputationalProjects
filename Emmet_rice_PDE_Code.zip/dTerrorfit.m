clc
clear all

maxz = 75;


%increase accuracy of difference, look for better than double


timeanalysis = 10000; %use 3000, and 10000

maxtimepts = 10000;
% deltatexact = 6.250000e-04;
% deltaxexact = 6.250000e-03;

deltatexact = 6.250000e-04;
deltaxexact = 3.125000e-03;

comparetime = 6; %the time point the values will be compared closest to
%note this is not the 6th time step but instead value closest to 6 seconds



 Dudt = zeros(maxz,1);
 Dudtav = zeros(maxz,1);
 deltatsq = zeros(maxz,1);
 deltatsqrt = zeros(maxz,1);
 deltatarray = zeros(maxz,1);

% Dudx = ones(maxz,:);
% deltaxsq = ones(maxz,:);

maxxpts1 = ceil(((2.0 * pi) / deltaxexact)+1);

%taken out of loop as exact solution wont change, done for speed

deltax = deltaxexact;
deltat = deltatexact;

[uxttest1, xpts1, times1] = FinDifWaveFn(maxtimepts, deltat, deltax, maxxpts1);



[~,idx1] = min(abs(xpts1-pi));   %finds closest point to pi from exact
      %as opposed to modulus method, there will be error introduced here as
         %its an approximation to closest pi value

[~,idt1] = min(abs(times1-comparetime)); 
%as times will not line up exactly find the closest one to time value 6

zuxttest1 = uxttest1(idt1, idx1);
%array for exact solution value at specific time and closest to pi 

zuxttest1av = uxttest1(idt1, :); 
%average value solution at specific time across all x

c=2;
k=c;

for w = 1:maxz  %only uses even integers
    
    z = (1 + (w - 1)/50);
    
    %this is to ensure that does not break cfl condition as this is the
    %multiplier on size of deltat, should never be less than c
    %for maxw of 75
    
    
%    if z == 0
%         z = 1;
%        
%    end
   
%    if z == 1
%         z = 3; %so function skips and doesnt repeat = 
%    end
    
%    if  mod(maxxpts1,z)==0
    
    deltax = deltaxexact;
    deltat = deltatexact;
    deltat2 = deltatexact * z; %increasing deltat for less accurate solution
    
    

    
    
    
%         maxxpts1 = ceil(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
        maxtimepts2 = floor(maxtimepts/z); %so ends at same time
               
        %IMPORTANT
        %This floor forces integer time steps but means the model wont end
        %exactly at the same time
        %this is why we use comparetime
        
        fprintf('\nrunning\n')
        
        %generating less accurate solution (larger deltax)
        [uxttest2, xpts2,times2] = FinDifWaveFn(maxtimepts2, deltat2, deltax, maxxpts1);

        
        
         
         [~,idx2] = min(abs(xpts2-pi));   %finds closest point to pi from erronious
        
         %as opposed to mod method, there will be error introduced here as
         %its an approximation to closest pi value
         
         [~,idt2] = min(abs(times2-comparetime));
         
         timeanalysis=times2(idt2);
          
         zuxttest2 = uxttest2(idt2, idx2);
         %chooses coulmn which indexes to pi x values 
        %chosen arbituary time value (comparetime) to compare
        
        Dudt(w) = (abs(zuxttest2 - zuxttest1));
        
        %can see from graph due, very wide spread of differences
        %again this is due to extreme gibs phenomenom
        
        %in order to see trend, again going to tale the average value in an
        %attempt o mitigate this effect, but again this approach is not at
        %all ideal or rigorous
        
        
         zuxttest2av = uxttest2(idt2, :);
        
         %READ
         %Ideally would take the difference between each corresponding xpt
         %then take the average, but requires the number of xpts of the
         %second to be modulus zero of original xpts, not large enough data
         %set
         
         %could also choose multiple close points to arbitaury values and
         %take their difference
         
         
         %instead, and not at all ideally, going to take average value for
         %u at all x points and then take the difference, which as noted is
         %not the same as the other way round, not as good
         
         
         
         
         
         Dudtav(w) = abs(mean(zuxttest2av) - mean(zuxttest1av)); %worse deltax - exactdeltax solution (closest to pi)
         
%         disp (Dudx(z))
        
        deltatarray(w) = deltat2;
        
         
         %plot Dudx vs deltax^2 and do chi squared fit
        
        
        %as opposed to convergence, now xpts1 will have more points
        %need to choose points which match up to trial
%         zxpts1 = xpts1(1:z:end,:); %selects rows so elemets so xpts match up
%         zuxttest1 = uxttest1(:, 1:z:end); %skips z many colums each time (x points stored in columns)

%         disp(size(xpts1))
%         disp(size(zxpts1))
        
%          colmean = mean(abs(uxttest2 - zuxttest1)); %worse deltax - exactdeltax solution (matching points)
%          Dudx(z) = mean(colmean); %stores average errorbetween 
%          deltaxsq(z) = ((deltax2)^2);   
%          %plot Dudx vs deltax^2 and do chi squared fit
         
         
%    else
%        continue
%          
%    end     
  
   
graphvalues2 = uxttest2(idt2,:);

figure(10)
plot(xpts2,graphvalues2)
mytitle = sprintf("Movie of model as deltat increases away from \napproxiamte exact dt value at \nTime =%0.5f \t timestep dt = %0.3e",times2(idt2),deltat2);
title(mytitle, 'FontSize', 14)
 xlabel("X");
 ylabel("U(x,t)");
% pause(0.1)

stabilitycheck = (deltax/deltat2);
fprintf('CFL must not less than %0.3f \t current value = %0.3f\n',k,stabilitycheck);
   
end

deltatsq = deltatarray.^2;
deltatsqrt = deltatarray.^0.5;


 figure(1)
scatter(deltatsq,Dudt)
hold on;
coeffs = polyfit(deltatsq, Dudt, 1);
% Get fitted values
fittedX = deltatsq;
%fittedX = (linspace(min(deltatarray), max(deltatarray), maxz)).^2;
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
mytitle = sprintf("Error Relationship for deltat values against \nsufficently exact dx and dt values \nat closest point to pi at time closest to %i",comparetime);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')
 xlabel("dt Squared");
 ylabel("U Error");
 
Chi2 = Chi(Dudt,fittedY,5);
fprintf('\nU error Dt^2 Chi2 = %0.3e\n',Chi2(1));
 
 

figure(2)
scatter(deltatarray,Dudt)
hold on;
coeffs = polyfit(deltatarray, Dudt, 1);
% Get fitted values
fittedX = deltatarray;
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

plot(fittedX, fittedY, 'r-', 'LineWidth', 3);
hold off;
mytitle = sprintf("Error Relationship for deltat values against \nsufficently exact dx and dt values \nat closest point to pi at time closest to %i",comparetime);
title(mytitle, 'FontSize', 14)
legend('Error','Visual Trend Line')
 xlabel("dt");
 ylabel("U Error");

Chi2 = Chi(Dudt,fittedY,5); 
fprintf('U error Dt Chi2 = %0.3e\n',Chi2(1));


 
 figure(3)
scatter(deltatsq,Dudtav)
hold on;
coeffs = polyfit(deltatsq, Dudtav, 1);
% Get fitted values
%fittedX = linspace(min(deltaxsq), max(deltaxsq), maxz);
%fittedX = (linspace(min(deltatarray), max(deltatarray), maxz)).^2;
fittedX = deltatsq;
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line


% plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
mytitle = sprintf("Error Relationship for deltat values against \nsufficently exact dx and dt values for \n Difference Between the Total Avergae U(x) Value\n at time closest to %i",comparetime);
title(mytitle, 'FontSize', 14)
% legend('Error','Visual Trend Line')
 xlabel("dt Squared");
 ylabel("Average U Error");
 
Chi2 = Chi(Dudtav,fittedY,5);
fprintf('Average U error Dt^2 Chi2 = %0.3e\n',Chi2(1));
 
 
 
figure(4)
scatter(deltatarray,Dudtav)
hold on;
coeffs = polyfit(deltatarray, Dudtav, 1);
% Get fitted values
fittedX = linspace(min(deltatarray), max(deltatarray), maxz);
fittedY = polyval(coeffs, fittedX);
% Plot the fitted line

% plot(fittedX, fittedY, 'r-', 'LineWidth', 3);    
hold off;
mytitle = sprintf("Error Relationship for deltat values against \nsufficently exact dx and dt values for \n Difference Between the Total Avergae U(x) Value\n at time closest to %i",comparetime);
title(mytitle, 'FontSize', 14)
% legend('Error','Visual Trend Line')
 xlabel("dt");
 ylabel("Average U Error");


Chi2 = Chi(Dudtav,fittedY,5);
fprintf('Average U error Dt Chi2 = %0.3e\n',Chi2(1));
 
 
 


function Chi2 = Chi(odata,edata,nepara)
    Chi2=sum(((odata-edata).^2)/edata)/(length(edata)-1-nepara);
    
end

