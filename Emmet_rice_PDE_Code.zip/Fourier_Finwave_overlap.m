clear all

global gn %a global value for 'n' iterations
.......

%using exact deltat and deltax needed for convergence

deltat    = 6.25e-04;
maxtimes  = 5;%number of steps


deltax=3.125e-03;
maxxpts = floor(((2.0 * pi) / deltax)+1);

maxseries=220;

[Fouruxt,xpts] = FourierWaveFn(maxtimes, deltat, deltax,maxseries);





[Finuxt] = FinDifWaveFn(maxtimes, deltat, deltax, maxxpts);


intuxt = (Fouruxt(end,:));
intFinuxt = (Finuxt(end,:));

plot(xpts,intuxt)
 mytitle = sprintf('Comparison of Square Wave Intial Condition\n to Fourier Wave Equation Approximation for N = %i ',maxseries);
 xlabel('x', 'FontSize', 14)
 ylabel('u(x,t)', 'FontSize', 14)
 xlim([0, 2*pi])
 title(mytitle, 'FontSize', 14)
hold on
plot(xpts,intFinuxt)
hold off

reduced_chi2 = Chi(intuxt,intFinuxt,1)

%note number of parameters in chi squared negliable due to sizeof data dominating
%see denominator in equation )

function Chi2 = Chi(odata,edata,nepara)
    Chi2=sum(((odata-edata).^2)/edata)/(length(edata)-1-nepara);
    
end


