clear all

global gn %a global value for 'n' iterations
.......

%using exact deltat and deltax needed for convergence

deltat    = 3.25e-05;
maxtimes  = 100;%number of steps


deltax=1.25e-02;
maxxpts = floor(((2.0 * pi) / deltax)+1);

maxseries=230;

[Fouruxt,xpts,an,times] = FourierHeatFn(maxtimes, deltat, deltax,maxseries);
[Finuxt,xpts2,times2] = CrankNichFn(maxtimes, deltat, deltax, maxxpts);




graphtime = 2;


specuxt = (Fouruxt(graphtime,:));
specFinuxt = (Finuxt(graphtime,:));

plot(xpts,specuxt)
 mytitle = sprintf('Comparison of Fourier Heat Approximation for N = %i\n to Crank Nicholson Approximation at time step t=%i',maxseries,graphtime);
 xlabel('x', 'FontSize', 14)
 ylabel('u(x,t)', 'FontSize', 14)
 xlim([0, 2*pi])
 title(mytitle, 'FontSize', 14)
hold on
plot(xpts,specFinuxt)
legend('Fourier series','Crank Nicholson')
hold off


