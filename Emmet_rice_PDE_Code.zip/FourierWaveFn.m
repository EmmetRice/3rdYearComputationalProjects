
%READ
%This code is incorrect as the 2 fundamental wave summations 
%do not super impose correct
%did not have time to correct



function [uxt, xpts,an,bn,times] = FourierWaveFn(maxtimes, deltat, deltax,maxseries);
global gn %a global value for 'n' iterations
.......

%fig1      = figure('Position', [100 100 900 400], 'Color', [1.0 1.0 1.0]);

%maxseries what n value going to sum to, find what value fo given acuracy


times     = zeros(maxtimes, 1);%set up array to store time points

maxxpts = floor(((2.0 * pi) / deltax)+1); % 1 more point than gap

xpts      = zeros(maxxpts, 1);%array to store points

% maxseries = 100; %what n value going to sum to, find what value fo given acuracy

lowint    = 0.0; %lower limit integration
highint   = 2 * pi; %upper limit integration

tol       = 1.0e-5; %relative accuracy of calc integral

an        = zeros(maxseries, 1); %stores the An coefficents for solution 
u         = zeros(maxxpts, 1); %stores solution for all x at specific t
uxt       = zeros(maxtimes, maxxpts); %stores solution U(x,t)


for ix = 1:maxxpts
      
   xpts(ix) = (ix - 1) * deltax;
   %setting up x point values

end


    for in = 1:maxseries

        gn     = in;

        myint  = quadl('series_f_Wave_an', lowint, highint, tol);
        bnfn = quadl('series_f_Wave_bn', lowint, highint, tol);
        %calculates integral of intial function using using recursive adaptive Lobatto quadrature
        %ie the numerical procedure
        an(in) = myint / pi;

        bn(in) = bnfn / (pi);
        %calculates and stores coefficent values
    end

    %disp('running')
    for itime = 1:maxtimes % sums over all times, with all x and n values

        times(itime) = (itime - 1) * deltat; %matlab starts at 1
        %set up time points

        for ix = 1:maxxpts % sums over all x values, with all n values

            sumseries = 0.0; %set up so can store sum series value as looped over

            for in = 1:maxseries %sums all n values
                
                innercosterm = an(in) * cos(in * times(itime));
                innersineterm = bn(in)* sin(in * times(itime));
                innerterms = innercosterm + innersineterm;
                    
                sumseries   = sumseries + (innerterms * sin((in * xpts(ix)) / 2));
%                 sumseries   = sumseries + ((an(in) * cos(in * times(itime))) +         ...
%                     (bn(in)*sin(in * times(itime)))) *...
%                     sin((in * xpts(ix)) / 2);


                % 	 sumseries   = sumseries + an(in) * sin(in * xpts(ix) / 2) *         ...
                % 	                           exp(-in * times(itime));

            end

            u(ix)          = sumseries; % only solution at current time
            uxt(itime, ix) = sumseries; %stores full solution



        end

        %Movie: Comment in /out as required to spead up

           plot1 = subplot(2, 2, 1);
        
            plot(xpts, u)
        
           xlim([0 2 * pi]);
           ylim([-2.0 2.0]);
           set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
        	    'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
        	    'FontSize', 14)
        
           mytitle = ['u(x,t) against x for a range of time values'];
           xlabel('x', 'FontSize', 14)
           ylabel('u(x,t)', 'FontSize', 14)
           title(mytitle, 'FontSize', 14)
        
           axis square
             drawnow
        
          

   
end
% maxuxt = imregionalmax(uxt); %not good enough as loads of maxima
