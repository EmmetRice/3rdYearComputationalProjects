function [uxt, xpts, times] = FinDifWaveFn(maxtimepts, deltat, deltax, maxxpts);



    % maxtimepts = 10000; %num of time steps
    % deltat     = 0.001; %sise time step
    % maxxpts    = 1001; %num of spatial grid points ie N. there will thus be N-1 STeps
     %deltax     = (2.0 * pi) / (maxxpts - 1); %1 less step than num grid pts

    %maxxpts = floor(((2.0 * pi) / deltax)+1);
    k          = 2.0; %from PDE, this k is actrually c .could soft code input
    u          = zeros(maxxpts, 1);
    approxU0   = zeros(maxxpts, 1);
    uxt        = zeros(maxtimepts, maxxpts); %stores solution U(x,t)
    g          = zeros(maxxpts, 1);
    xpts       = zeros(maxxpts, 1);
    times      = zeros(maxtimepts, 1);
    


    alpha      = (k ^2)* (deltat*deltat) / ( deltax * deltax); %2 term from eq 5.45 denominator
    %1/2 term as averaging over n and n+1 time step (itime)

    CFLtest = deltax/deltat;

    %STABILITY CFL
     if CFLtest <= k
            fprintf('\nCFL not met in function\n')
            return
     end

    % initial condition
    for ix = 1:maxxpts

       xpts(ix) = (ix - 1) * deltax; %so x(0) = 0, 1 less gap than points

       if (xpts(ix) < pi - 2)

          u(ix) = 0;

       elseif (pi - 2 <= xpts(ix) &&  xpts(ix) <= pi + 2)

          u(ix) = 1;

       else

          u(ix) = 0; 

       end

    end


    uxt(1,:) = u;
    g(ix) = sin(ix/2);

    upre = zeros(maxxpts, 1);
    unow  = u;
    unext  = zeros(maxxpts, 1);

   

 
    for itime = 1:maxtimepts-1 %as code generates next time step

        

       times(itime) = itime * deltat; %array to store time point



       for ix = 2:(maxxpts - 1) % as know at boundary = 0 (ix = 1 and max)

                    
           

          if itime == 1
                upre(ix) = unow(ix) - (2*deltat*g(ix)); %ie  = uxt(itime -1, ix)

                unext(ix) = (2*(1 - alpha)*unow(ix)) - upre(ix)...
                            +(alpha*(unow(ix - 1) + unow(ix + 1)));

          else
                 unext(ix) = (2*(1 - alpha)*unow(ix)) - upre(ix)...
                            +(alpha*(unow(ix - 1) + unow(ix + 1)));


           %from handout eqaution for RHS of AU(ix,n+1) = r ( r based on n time
           %step)
          end 



       end


       
       uxt(itime+1,:) = unext;

       %setting variables for next iteration   
       upre = unow;
       unow=unext;

       %setting u just for plot
       u = uxt(itime, :);
       
       
%        plot(xpts, u, '-r')
%        
%        xlim([0, 3*pi])
%        ylim([-1.2, 1.2])
%        
%        drawnow

    end
    
    
end