maxtimepts = 10;
deltat     = 0.01;
maxxpts    = 101;
deltax     = (2.0 * pi) / (maxxpts - 1);

k          = 2.0;

u          = zeros(maxxpts, 1);
xpts       = zeros(maxxpts, 1);


times       = zeros(maxtimepts, 1);

amatsize   = maxxpts - 2;
amat       = zeros(amatsize, amatsize);
rhs        = zeros(amatsize, 1);
alpha      = (k * deltat) / (2.0 * deltax * deltax);

for ix = 1:maxxpts
   
   xpts(ix) = (ix - 1) * deltax;
   
   if (xpts(ix) < pi)
      
      u(ix) = xpts(ix) / pi;
   
   else
      
      u(ix) = sin(0.5 * xpts(ix));
      
   end

end

plot(xpts, u, '-b');

xlim([0, 2 * pi])
ylim([0, 1.2])
set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		 ...
	 'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		 ...
	 'FontSize', 14)   

mytitle = ['Graph of u(x,t) against x for a range of time values'];
xlabel('x', 'FontSize', 14)
ylabel('u(x,t)', 'FontSize', 14)
title(mytitle, 'FontSize', 14)

hold on
drawnow

for jx = 1:amatsize
   for ix = 1:amatsize
      
      if (ix == jx + 1)
         
	 amat(ix, jx) = -alpha;
      
      elseif (ix == jx)
         
	 amat(ix, jx) = 1 + 2 * alpha;
	 
      elseif (ix == jx - 1)
         
	 amat(ix, jx) = -alpha;
      
      end
      
   end
end

for itime = 1:maxtimepts
   
   times(itime) = itime * deltat;
   
   for ix = 2:(maxxpts - 1)
      
      a           = alpha * u(ix - 1) + (1 - 2 * alpha) * u(ix) +            ...
                    alpha * u(ix + 1);
      rhs(ix - 1) = a;
      
   end
   
   vv = crout(amat, rhs);
   
   for ix = 2:(maxxpts - 1)
      
      u(ix) = vv(ix - 1);
      
   end
   
   plot(xpts, u, '-r')
   xlim([0, 2*pi])
   ylim([0, 1.2])
   
   drawnow

end

