% Crank nicholson video basic

deltat=3.125000e-04; 	
deltax=1.250000e-01;
maxxpts = ceil(((2.0 * pi) / deltax)+1);

% Realised late into writting report that the above does not limit the 
%bar sufficently to 2pi (or close enough to be negligable)
%below documents a late attempt to fix, this does not force equal to 2pi
%and runs into issues with how the convergence code is conducted

% barsize = maxxpts*deltax;
% pointslost=0;
% while barsize>(2.0*pi)
%     maxxpts = maxxpts-1;
%     barsize = maxxpts*deltax;
%     pointslost = pointslost + 1;
% end
% disp(pointslost)


maxtimepts = 3000;

[uxt, xpts,times] = CrankNichFn(maxtimepts, deltat, deltax, maxxpts);

plot4 = subplot(2,2,[1 4]);
surf(xpts, times, uxt)
shading interp

xlim([0 2 * pi]);
%ylim([0 1.0]);
zlim([0 2.0]);

set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
	 'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
	 'FontSize', 14)   
   
mytitle = sprintf('Time Evolution of Diffusion Equation\nCrank Nicholson Method');
xlabel('X', 'FontSize', 14)
ylabel('Time(t)', 'FontSize', 14)
zlabel('u(x,t)', 'FontSize', 14)
title(mytitle, 'FontSize', 14)

axis square

function [uxt, xpts,times] = CrankNichFn(maxtimepts, deltat, deltax, maxxpts);

    % maxtimepts = 100; %num of time steps
    % deltat     = 0.01; %sise time step
    % maxxpts    = 101; %num of spatial grid points ie N. there will thus be N-1 STeps
    % deltax     = (2.0 * pi) / (maxxpts - 1); %1 less step than num grid pts

    k          = 2.0; %from PDE
    u          = zeros(maxxpts, 1);
    xpts       = zeros(maxxpts, 1);
    times       = zeros(maxtimepts, 1);

    amatsize   = maxxpts - 2; %size of the matric A is 2 elements less as from BC edge points known = 0
    amat       = zeros(amatsize, amatsize); %matric to store A matrix
    rhs        = zeros(amatsize, 1); %right hand values of matricx equation
    alpha      = (k * deltat) / (2.0 * deltax * deltax); %2 term from eq 5.45 denominator
    %1/2 term as averaging over n and n+1 time step (itime)


    %initial condition
    for ix = 1:maxxpts

       xpts(ix) = (ix - 1) * deltax; %so x(0) = 0

       if (xpts(ix) < pi - 1)

          u(ix) = 0;

       elseif (pi - 1 <= xpts(ix) &&  xpts(ix) <= pi + 1)

          u(ix) = 1;

       else

          u(ix) = 0; 

       end

    end

uxt(1,:) = u;
  

    plot(xpts, u, '-b');

    xlim([0, 3 * pi])
    ylim([0, 1.2])
    set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		 ...
         'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		 ...
         'FontSize', 14)   

    mytitle = ['Graph of u(x,t) against x for a range of time values'];
    xlabel('x', 'FontSize', 14)
    ylabel('u(x,t)', 'FontSize', 14)
    title(mytitle, 'FontSize', 14)

    %hold on
    drawnow

    %Seting up A matrix for LU decomposition (see notes)
    for jx = 1:amatsize
       for ix = 1:amatsize

          if (ix == jx + 1)

         amat(ix, jx) = -alpha;

          elseif (ix == jx)

         amat(ix, jx) = 1 + 2 * alpha;

          elseif (ix == jx - 1)

         amat(ix, jx) = -alpha;

          end

       end
    end

    for itime = 1:maxtimepts

       times(itime) = (itime * deltat)-deltat; %array to store time point

       for ix = 2:(maxxpts - 1) % as know at boundary = 0 (ix = 1 and max)

           %from handout eqaution for RHS of AU(ix,n+1) = r ( r based on n time
           %step)

          a           = alpha * u(ix - 1) + (1 - 2 * alpha) * u(ix) +            ...
                        alpha * u(ix + 1); 
          rhs(ix - 1) = a; %ix -1 as ix starts at 2 but need RHS array start at element 1

       end

       vv = crout(amat, rhs); % the solved unknown u(x) values

       for ix = 2:(maxxpts - 1) % starting points known set = 0 (ix =1, max)

          u(ix) = vv(ix - 1); %element 2 of u = element 1 of vv

       end
       
       
       uxt(itime,:) = u;
       
       plot(xpts, u, '-r')
       xlim([0, 3*pi])
       ylim([0, 1.2])
       drawnow

    end
end 


%        disp(xpts(end))
%        disp(uxt(itime,end))
