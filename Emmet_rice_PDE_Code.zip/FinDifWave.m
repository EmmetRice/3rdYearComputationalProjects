clc
close all;
clear all;
%finite diff wave equation

% maxtimepts = 10000; %num of time steps
% deltat     = 0.0001; %sise time step
% %maxxpts    = 1001; %num of spatial grid points ie N. there will thus be N-1 STeps
% %deltax     = (2.0 * pi) / (maxxpts - 1); %1 less step than num grid pts
% deltax     = 6.283185e-04;
% CFLtest1 = deltax/deltat;


% fprintf('deltax \t%d\n',deltax)
% fprintf('deltat \t%d\n',deltat)
% fprintf('CFLtest1\t%d\n',CFLtest1)

counter      = 0;
counterLimit = 100000;


%toldesired = input('Input esired tolerance for convergence, example 1e-03  ');
toldesired = 5e-02;
tol = 1;
%deltax = input('......');

maxtimepts = 10000; %num of time steps
deltat = 0.01;
deltax = 10 * deltat;

flag = 0;
c = 2.0;
k=c; 

%IMPORTANT, K is used in the code for ease of transferring, but note that K is actually C
%not C^2 

%for convergence
    
    while tol > toldesired && counter < counterLimit %so does not run forever
    %     
         CFLtest = deltax/deltat;
        
         disp(k)
         
         if CFLtest <= k
             fprintf('\nStability CFL condition no longer met\nfor halfing deltax. Must use smaller deltat\n')
             fprintf('\n CFL = %0.3f \t deltat = %d \t deltax = %d\n',CFLtest, deltat, deltax)
             deltat = 0.25*deltat;
             fprintf('new deltat = \t %d\n',deltat)
             CFLtest = deltax/deltat;
             fprintf('newCFL\t%.3f\n',CFLtest)
         end

         if counter == counterLimit
          warning('failed')
         end
         
       
        deltax2 = 0.5*deltax; %choosing smaller delta x to get to convergence
        maxxpts1 = floor(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
        maxxpts2 = 2*maxxpts1;
        fprintf('\nrunning\n')
        [uxttest1, xpts1] = FinDifWaveFn(maxtimepts, deltat, deltax,maxxpts1);
        [uxttest2, xpts2] = FinDifWaveFn(maxtimepts, deltat, deltax2,maxxpts2);

        oddxpts2 = xpts2(1:2:end,:); %selects odd row elemets so xpts match up
        odduxttest2 = uxttest2(:, 1:2:end); %chooses only odd columns
        % ie so that x values match up

        %xpts1 - oddxpts2 shows that everyother xpt lines up

    %     fprintf('size uxtest1 \t%d\n',size(uxttest1));
    %     fprintf('size uxtest2 \t%d\n',size(uxttest2));
    %     fprintf('size odduxtest2 \t%d\n',size(odduxttest2));
        %test 2 has twice as many points as 1, but as matlab array start at 1,
        %all odd elements will line up

        %tol = (norm(uxttest1 - odduxttest2)); %norm function takes largeest value
        %IDEALLY would use norm function, choosing largest discrepancy within
        %tolerance, but due to gibs, this is an unrealistic measure
       %while strictly worse analysis, in order to show convergence, taking the
       %average value of the difference

       colmean = mean(abs(uxttest1 - odduxttest2));
       tol = mean(colmean);
       
        fprintf ('\nTemporary results...\n')
        fprintf('CFL\t%.3f\n',CFLtest)
        fprintf('deltat\t%d \tdeltax\t%d\n',deltat, deltax)
        fprintf('tol\t%.3f\n',tol)
                
        
         if CFLtest <= k
             tol =1;
           
         end    


        deltax = deltax2; %for next loop iteration
        counter = counter + 1; 

        

        if tol <= toldesired 

            deltax = 2* deltax; %as now within tolerance, choose larger  deltax)
            fprintf('\nCOMPLETE\n')
            fprintf('deltax = %d required for convergence at deltat = %d\n',deltax, deltat)
            fprintf('Tolerance desired\t%d\n',toldesired)
            fprintf('average difference in uxt\t%d\n',tol)
            fprintf('CFL\t%.3f\n',CFLtest)
        end
    end

    % FOR SHOWING MASSIVE differences at step points
    % %     diff = (uxttest1 - odduxttest2);
    %     %plot(xpts1, diff(20,:), '-r')
    %     plot(xpts1, uxttest1(20,:), '-r')
    %     hold on
    %     plot (xpts1, odduxttest2(20,:), '-b')

    

    
    
    %CONVERGENCE of DELTA T
    
    %DELTA X CARRIED FORWARD FROM CONVERGENCE ABOVE
    
tol2 = 1;    
    
while tol2 > toldesired && counter < counterLimit %so does not run forever
    %     
         CFLtest = deltax/deltat;
        
         
         
         if CFLtest <= k
             fprintf('\nStability CFL condition no longer met\nfor halfing deltax. Must use smaller deltat\n')
             fprintf('\n CFL = %0.3f \t deltat = %d \t deltax = %d\n',CFLtest, deltat, deltax)
%              deltax = 0.25*deltax;
%              fprintf('new deltat = \t %d\n',deltat)
%              CFLtest = deltax/deltat;
%              fprintf('newCFL\t%.3f\n',CFLtest)
            break
         end    
    
    
    if counter == counterLimit
          warning('failed')
    end
    
    deltat2 = 0.5*deltat; %choosing smaller delta t to get to convergence
    
    maxxpts = floor(((2.0 * pi) / deltax)+1); %floor so that integer, also 1 more point than steps
    maxtimepts2 = 2*maxtimepts; %smaller deltat = twice pts
    
    fprintf('\nrunning\n')
    [uxttest1] = FinDifWaveFn(maxtimepts, deltat, deltax,maxxpts);
    [uxttest2] = FinDifWaveFn(maxtimepts2, deltat2, deltax,maxxpts);
    
    
     oddtimeuxttest2 = uxttest2(1:2:end,:); %chooses only odd rows
     % ie so that time values match up (as twice amount)
        
     rowmean = mean(abs(uxttest1 - oddtimeuxttest2));
     tol2 = mean(rowmean);
     
     fprintf ('\nTemporary results...\n')
     fprintf('CFL\t%.3f\n',CFLtest)
     fprintf('deltat\t%d \tdeltax\t%d\n',deltat, deltax)
     fprintf('tol\t%.3f\n',tol2)
     
     
     if CFLtest <= k
         tol2 =1;
         
     end
        
    
     deltat = deltat2; %for next loop iteration
     maxtimepts = maxtimepts2;
     counter = counter + 1;
     
     
     
     if tol <= toldesired
         
         deltat = 2* deltat; %as now within tolerance, choose larger  deltax)
         fprintf('\nCOMPLETE TIME CONVERGENCE\n')
         fprintf(2,'deltat = %d required for time convergence at convergent deltax = %d\n',deltat, deltax)
         fprintf('Tolerance desired\t%d\n',toldesired)
         fprintf('average difference in uxt for time convergence\t%d\n',tol2)
         fprintf('CFL\t%.3f\n',CFLtest)
        
     end
end
     
    

%Order of error

deltatexact = deltat;
deltaxexact = deltax;





