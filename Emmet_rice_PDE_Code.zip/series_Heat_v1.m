
function [uxt, xpts,an,bn,times] = FourierHeatFn(maxtimes, deltat, deltax,maxseries);

global gn %a global value for 'n' iterations
.......

%maxseries what n value going to sum to, find what value fo given acuracy



times     = zeros(maxtimes, 1);%set up array to store time points

maxxpts = floor(((2.0 * pi) / deltax)+1); % 1 more point than gap


xpts      = zeros(maxxpts, 1);%array to store points

%maxseries what n value going to sum to, find what value fo given acuracy

lowint    = 0.0; %lower limit integration
highint   = 2 * pi; %upper limit integration

tol       = 1.0e-5; %relative accuracy of calc integral

an        = zeros(maxseries, 1); %stores the An coefficents for solution 
u         = zeros(maxxpts, 1); %stores solution for all x at specific t
uxt       = zeros(maxtimes, maxxpts); %stores solution U(x,t)

for ix = 1:maxxpts
      
   xpts(ix) = (ix - 1) * deltax;
   %setting up x point values

end

for in = 1:maxseries
   
   gn     = in;
   
   myint  = quadl('series_f_Heat', lowint, highint, tol);
   %calculates integral of intial function using using recursive adaptive Lobatto quadrature
   %ie the numerical procedure
   an(in) = myint / pi;
   %calculates and stores coefficent values
end

for itime = 1:maxtimes % sums over all times, with all x and n values
   
   times(itime) = (itime - 1) * deltat; %matlab starts at 1
   %set up time points
   
   for ix = 1:maxxpts % sums over all x values, with all n values
      
      sumseries = 0.0; %set up so can store sum series value as looped over
      
      for in = 1:maxseries %sums all n values
         
	 sumseries   = sumseries + an(in) * sin(in * xpts(ix) / 2) *         ...
	                           exp(-in * times(itime));
      
      end
      
      u(ix)          = sumseries; % only solution at current time
      uxt(itime, ix) = sumseries; %stores full solution
   end
   
   plot1 = subplot(1, 2, 1);
   
   plot(xpts, u)
   
   xlim([0 2 * pi]);
   ylim([0 1.0]);
   set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
	    'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
	    'FontSize', 14)   
   
   mytitle = ['u(x,t) against x for a range of time values'];
   xlabel('x', 'FontSize', 14)
   ylabel('u(x,t)', 'FontSize', 14)
   title(mytitle, 'FontSize', 14)
   
   axis square
   
   hold on
   drawnow

end

plot2 = subplot(1, 2, 2);

surf(xpts, times, uxt)
shading interp

xlim([0 2 * pi]);
ylim([0 1.0]);
zlim([0 1.0]);

set(gca, 'Color', [1.0 1.0 1.0],'XColor', [0.0 0.0 0.0],		     ...
	 'YColor', [0.0 0.0 0.0], 'ZColor', [0.0 0.0 0.0],		     ...
	 'FontSize', 14)   
   
mytitle = ['u(x,t) as a function of x and t'];
xlabel('x', 'FontSize', 14)
ylabel('t', 'FontSize', 14)
zlabel('u(x,t)', 'FontSize', 14)
title(mytitle, 'FontSize', 14)

axis square
   
      
   
